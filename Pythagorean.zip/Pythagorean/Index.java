public class Index {
    public static void main(String[] args) {
        Pythagorean iD = new Pythagorean();
        Double hypo = iD.calculateHypotenuse(5, 8);
        System.out.println(hypo);
    }
}
