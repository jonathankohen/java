public class First {
    public static void main(String[] args) {
        System.out.println("My name is Jon");
        System.out.println("I am " + 120 + " years old");
        System.out.println("My hometown is Lowell, MA");
    }
}
